# Fiji Plugin N-D Sequence Registration

## Installation

- [Fiji > Help > Update]
	- [Manage Update Sites]
	- [X] EMBL-CBA
	- [X] BigStitcher
		- This dependency might disappear in the future once the phasecorrelation code is available in imglib2
- Restart Fiji
- [Fiji > Plugins > Registration > N-D Sequence Registration]

 
