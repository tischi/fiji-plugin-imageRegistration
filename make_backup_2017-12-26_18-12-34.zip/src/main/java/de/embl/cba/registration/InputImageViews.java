package de.embl.cba.registration;

import de.embl.cba.registration.axessettings.AxesSettings;
import net.imagej.Dataset;
import net.imagej.DatasetService;
import net.imagej.ImgPlus;
import net.imagej.axis.AxisType;
import net.imglib2.FinalInterval;
import net.imglib2.RandomAccessible;
import net.imglib2.RandomAccessibleInterval;
import net.imglib2.RealRandomAccessible;
import net.imglib2.concatenate.Concatenable;
import net.imglib2.concatenate.PreConcatenable;
import net.imglib2.img.Img;
import net.imglib2.interpolation.randomaccess.NLinearInterpolatorFactory;
import net.imglib2.realtransform.InvertibleRealTransform;
import net.imglib2.realtransform.RealViews;
import net.imglib2.type.NativeType;
import net.imglib2.type.numeric.RealType;
import net.imglib2.util.Intervals;
import net.imglib2.view.Views;

import java.util.*;

public class InputImageViews
        < R extends RealType< R > & NativeType< R >,
                T extends InvertibleRealTransform & Concatenable< T > & PreConcatenable< T > > {

    final RandomAccessibleInterval inputRAI;
    final AxesSettings axesSettings;
    private DatasetService datasetService;

    public InputImageViews( RandomAccessibleInterval inputImage,
                            AxesSettings axesSettings,
                            DatasetService datasetService )
    {
        this.inputRAI = inputImage;
        this.axesSettings = axesSettings;
        this.datasetService = datasetService;
    }


    public Img< R > asImgPlus( RandomAccessibleInterval< R > rai )
    {
        assert inputRAI.numDimensions() == rai.numDimensions();

        Dataset dataset = datasetService.create( Views.zeroMin( rai ) );

        ImgPlus img = new ImgPlus( dataset, "transformed", inputImgAxisTypes() );

        // TODO: better to return as Dataset? E.g. for KNIME?

        return img;
    }

    public AxisType[] inputImgAxisTypes()
    {
        return null;
    }

    public RandomAccessibleInterval< R > referenceInterval( RandomAccessible< R > ra )
    {
        return Views.interval( ra, axesSettings.transformableAxesReferenceInterval() );
    }


    public RandomAccessible< R > transform( RandomAccessibleInterval< R > rai, InvertibleRealTransform transform )
    {
        // TODO: make single lines
        RealRandomAccessible rra
                = RealViews.transform(
                        Views.interpolate( Views.extendBorder( rai ), new NLinearInterpolatorFactory() ),
                                    transform );

        RandomAccessible transformedRA = Views.raster( rra );

        return transformedRA;
    }

    public RandomAccessible transform( RandomAccessible ra, InvertibleRealTransform transform )
    {

        // TODO: make single lines
        RealRandomAccessible rra
                = RealViews.transform(
                        Views.interpolate( ra, new NLinearInterpolatorFactory() ),
                            transform );

        RandomAccessible transformedRA = Views.raster( rra );

        return transformedRA;
    }


    public RandomAccessibleInterval transformableHyperSlice( long s )
    {
        return transformableHyperSlice( s, axesSettings.fixedReferenceCoordinates() );
    }

    public RandomAccessibleInterval transformableHyperSlice(
            long s,
            long[] fixedAxesCoordinates )
    {

        // TODO: simplify below
        long[] min = Intervals.minAsLongArray( inputRAI );
        long[] max = Intervals.maxAsLongArray( inputRAI );

        min[ axesSettings.sequenceDimension() ] = s;
        max[ axesSettings.sequenceDimension() ] = s;

        setFixedAxesCoordinates( fixedAxesCoordinates, min, max );

        FinalInterval interval = new FinalInterval( min, max );

        RandomAccessibleInterval rai =
                Views.dropSingletonDimensions(
                        Views.interval( inputRAI, interval ) );

        return rai;

    }

    private void setFixedAxesCoordinates( long[] fixedAxesCoordinates, long[] min, long[] max )
    {
        for ( int i = 0; i < axesSettings.numFixedDimensions( ); ++i )
        {
            int d = axesSettings.fixedDimension( i );
            min[ d ] = fixedAxesCoordinates[ i ];
            max[ d ] = fixedAxesCoordinates[ i ];
        }
    }


    private RandomAccessibleInterval transformedRAI(
            long s,
            InvertibleRealTransform transform,
            Map< Integer, Long > fixedDimensions,
            FinalInterval transformableDimensionsInterval )
    {
        RandomAccessibleInterval rai;

        rai = transformableHyperSlice( s, fixedDimensions );

        rai = Views.interval(
                transform( rai, transform ),
                transformableDimensionsInterval );

        return rai;
    }


    public RandomAccessibleInterval< R > transformedInputRAI( Map< Long, T > transformations )
    {

        // For each combination of the fixed axes ( Map< Integer, Long > )
        // generate a transformed RAI sequence
        Map< Map< Integer, Long >, RandomAccessibleInterval < R > >
                transformedSequenceMap = new HashMap<>(  );

        // Fixed axes map.
        // This serves to indicate whether the axis has been transformed already or not (null).
        Map< Integer, Long > fixedDimensions = new HashMap<>();

        for ( int d : axesSettings.fixedDimensions() )
        {
            fixedDimensions.put( d, Long.MAX_VALUE );
        }

        RandomAccessibleInterval transformedRAI =
                createTransformedInputRAISequence(
                        transformedSequenceMap,
                        fixedDimensions,
                        transformations );

        transformedRAI = Views.dropSingletonDimensions( transformedRAI );

        // TODO: fix dimension order such that it is the same as in input image

        return transformedRAI;
    }


    private RandomAccessibleInterval createTransformedInputRAISequence(
            Map< Map< Integer, Long >, RandomAccessibleInterval < R > >  transformedSequenceMap,
            Map< Integer, Long > dimensionCoordinateMap,
            Map< Long, T > transformations )
    {

        // TODO: probably possible to do this cleaner...

        if ( dimensionCoordinateMap.containsValue( Long.MAX_VALUE ) )
        {
            List< RandomAccessibleInterval< R > > dimensionCoordinateRAIList = new ArrayList<>(  );

            for ( int d : dimensionCoordinateMap.keySet() )
            {
                if ( dimensionCoordinateMap.get( d ) == Long.MAX_VALUE )
                {
                    List < RandomAccessibleInterval< R > > sequenceCoordinateRAIList = new ArrayList<>(  );

                    for (long c = inputRAI.min( d ); c <= inputRAI.max( d ); ++c )
                    {
                        Map< Integer, Long > newFixedDimensions =
                                new LinkedHashMap<>( dimensionCoordinateMap );

                        newFixedDimensions.put( d, c );

                        sequenceCoordinateRAIList.add(
                                createTransformedInputRAISequence(
                                        transformedSequenceMap,
                                        newFixedDimensions,
                                        transformations ) );

                    }
                    dimensionCoordinateRAIList.add(  Views.stack( sequenceCoordinateRAIList ) );
                }
            }
            return Views.stack( dimensionCoordinateRAIList );
        }
        else
        {
            List< RandomAccessibleInterval< R > > transformedRAIList = new ArrayList<>();

            for (long s = input.min( sequenceAxisProperties.axis );
                 s <= input.max( sequenceAxisProperties.axis );
                 ++s )
            {
                if ( transformations.containsKey( s ) )
                {

                    transformedRAIList.add(
                            getTransformedRAI(
                                    s,
                                    transformations.get( s ),
                                    dimensionCoordinateMap,
                                    getTransformableDimensionsOutputInterval() )
                    );
                }
            }
            // combine time-series of multiple channels into a channel stack
            RandomAccessibleInterval< R > transformedSequence = Views.stack( transformedRAIList );

            transformedSequenceMap.put( dimensionCoordinateMap, transformedSequence );

            return transformedSequence;
        }

    }


}
