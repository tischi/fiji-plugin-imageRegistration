package de.embl.cba.registration.gui;

public class UIParameters
{
}
