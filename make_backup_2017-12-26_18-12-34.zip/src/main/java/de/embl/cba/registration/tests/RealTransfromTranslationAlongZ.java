package de.embl.cba.registration.tests;


// Import does not work
//import net.imglib2.realtransform.RealTransformSequence;
//import net.imglib2.realtransform.RealTransform;


/**
 * Created by tischi on 28/09/17.
 */


/*

https://github.com/imglib/imglib2-realtransform/blob/master/src/main/java/net/imglib2/realtransform/AffineTransform2D.java

https://github.com/imglib/imglib2-realtransform/blob/master/src/main/java/net/imglib2/realtransform/AbstractRealTransformSequence.java


!! This seems to actually already do everything that we need:
https://github.com/imglib/imglib2-realtransform/blob/master/src/main/java/net/imglib2/realtransform/RealTransformSequence.java

 */


public class RealTransfromTranslationAlongZ {


}
