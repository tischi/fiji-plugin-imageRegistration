package de.embl.cba.registration.transformationfinders;

public class TransformationFinderParameters {

    public final static String MAXIMAL_TRANSLATIONS = "Maximal translations";
    public final static String MAXIMAL_ROTATIONS = "Maximal rotations";
    public final static String TRANSFORMATION_FINDER_TYPE = "Transformation finder type";
    public final static String IMAGE_FILTER = "Image filter";
    public final static String LOGGER_SERVICE = "Logger service";


}
