package de.embl.cba.registration;

public enum OutputViewIntervalSizeTypes {

    ReferenceRegionSize,
    InputDataSize,
    UnionSize;

}
