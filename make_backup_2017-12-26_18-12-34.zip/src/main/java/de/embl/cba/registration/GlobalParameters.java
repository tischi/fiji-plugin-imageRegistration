package de.embl.cba.registration;

public class GlobalParameters {

    public static final String LOG_SERVICE = "Log executorService";
    public static final String EXECUTOR_SERVICE = "Executor executorService";

}
