package de.embl.cba.registration;

import java.util.ArrayList;

public enum RegistrationAxisTypes {

    Sequence,
    Transformable,
    Fixed;

}
