package de.embl.cba.registration;

public enum ReferenceRegionTypes {

    Moving,
    Fixed;

}
