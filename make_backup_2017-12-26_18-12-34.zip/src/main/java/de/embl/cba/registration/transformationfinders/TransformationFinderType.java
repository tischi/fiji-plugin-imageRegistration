package de.embl.cba.registration.transformationfinders;

public enum TransformationFinderType {

    Translation__PhaseCorrelation,
    Rotation_Translation__PhaseCorrelation;

}
