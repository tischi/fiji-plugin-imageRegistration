package de.embl.cba.registration;

public enum ReferenceRegionType
{
    Moving,
    Fixed;
}
