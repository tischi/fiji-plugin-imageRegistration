package de.embl.cba.registration.transformfinder;

public enum TransformFinderType
{

    Translation__PhaseCorrelation,
    Rotation_Translation__PhaseCorrelation;

}
