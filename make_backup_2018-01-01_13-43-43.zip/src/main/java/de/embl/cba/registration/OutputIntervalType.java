package de.embl.cba.registration;

public enum OutputIntervalType
{
    ReferenceRegionSize,
    InputDataSize,
    UnionSize
}
