import bdv.spimdata.SpimDataMinimal;
import bdv.spimdata.XmlIoSpimDataMinimal;
import bdv.util.Bdv;
import bdv.util.BdvFunctions;
import bdv.util.BdvStackSource;
import bdv.viewer.SourceAndConverter;
import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import io.scif.img.ImgIOException;
import mpicbg.spim.data.SpimDataException;
import net.imglib2.img.Img;
import net.imglib2.img.array.ArrayImg;
import net.imglib2.img.array.ArrayImgs;
import net.imglib2.img.display.imagej.ImageJFunctions;
import net.imglib2.type.NativeType;
import net.imglib2.type.numeric.ARGBType;
import net.imglib2.type.numeric.NumericType;
import net.imglib2.img.basictypeaccess.array.IntArray;
import org.jruby.lexer.yacc.StackState;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LearnBigDataViewer
{

    public LearnBigDataViewer() throws SpimDataException
    {
        test2();
    }

    public void test()
    {

        final Random random = new Random();

        final ArrayImg< ARGBType, IntArray > img = ArrayImgs.argbs( 100, 100, 100 );
        img.forEach( t -> t.set( random.nextInt() & 0xFF00FF00 ) );
        final Bdv bdv3D = BdvFunctions.show( img, "greens" );

        final ArrayImg< ARGBType, IntArray > img2 = ArrayImgs.argbs( 100, 100, 100 );
        img2.forEach( t -> t.set( random.nextInt() & 0xFFFF0000 ) );
        BdvFunctions.show( img2, "reds", Bdv.options().addTo( bdv3D ) );


    }


    public void test2() throws SpimDataException
    {

        // open em-raw 500nm from Bdv and show in Bdv
        //
        System.setProperty( "apple.laf.useScreenMenuBar", "true" );

        final String xmlFilename = "/Users/tischer/Desktop/tmp7/tmp8/em-raw-250nm.xml";
        final SpimDataMinimal spimData = new XmlIoSpimDataMinimal().load( xmlFilename );
        Bdv bdv = BdvFunctions.show( spimData ).get( 0 );

        ImagePlus imp = IJ.openImage( "/Users/tischer/Documents/detlev-arendt-clem-registration/data/prospr-aligned/C2-Mitf-aligned.tif");
        Img img = ImageJFunctions.wrap( imp );

        BdvFunctions.show( img, "Mitf", Bdv.options().addTo( bdv ) );


        //bdv.getBdvHandle().getViewerPanel().addSource(  );

        // open mitf-aligned from tiff and add as a second source
        //

    }

    public static void main( String[] args ) throws ImgIOException, SpimDataException
    {
        // open an ImageJ window
        new ImageJ();

        // run the example
        new LearnBigDataViewer();
    }
}
