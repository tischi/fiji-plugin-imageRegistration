package de.embl.cba.registration;

public enum OutputIntervalSizeType
{
    InputImage,
    TransformationsEncompassing
}
