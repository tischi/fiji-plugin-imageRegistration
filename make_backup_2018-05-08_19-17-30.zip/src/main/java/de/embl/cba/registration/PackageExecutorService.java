package de.embl.cba.registration;

import java.util.concurrent.ExecutorService;

public class PackageExecutorService
{
    public static ExecutorService executorService;
}
