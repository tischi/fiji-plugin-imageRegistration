package de.embl.cba.registration.util;

import net.imagej.ImgPlus;

public class SciJavaUtils
{

    public ImgPlus setImgPlusInMetaImage( MetaImage metaImage )
    {
        return null;
    }
}
