package de.embl.cba.registration.transformfinder;

public enum TransformFinderType
{

    Translation__PhaseCorrelation,
    Translation__Maximum,
    Rotation_Translation__PhaseCorrelation;

}
